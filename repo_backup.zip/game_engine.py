class RadarTrackingFilterEngine:
    def __init__(self, process_noise=0.05, measurement_noise=0.5):
        self.q = process_noise
        self.r = measurement_noise
    def update_track(self, predicted_position_m=5000.0, measured_position_m=5045.0):
        kalman_gain = self.q / (self.q + self.r)
        filtered_position = predicted_position_m + kalman_gain * (measured_position_m - predicted_position_m)
        position_error = abs(filtered_position - measured_position_m)
        status = "TRACK LOCKED / KALMAN FILTER CONVERGED" if position_error < 25.0 else "TRACK DRIFT / HIGH UNCERTAINTY"
        print(f"[RADAR TRACKING] Predicted: {predicted_position_m}m | Measured: {measured_position_m}m")
        print(f"[KALMAN FILTER] Gain: {kalman_gain:.3f} | Filtered Position: {filtered_position:.1f}m")
        print(f"[TRACK STATUS] {status}")
        return filtered_position, kalman_gain
print("--- TACTICAL SIMULATION ENGINE: RADAR TRACKING & KALMAN FILTER ---")
kf = RadarTrackingFilterEngine(process_noise=0.08, measurement_noise=0.4)
kf.update_track(predicted_position_m=4800.0, measured_position_m=4830.0)
